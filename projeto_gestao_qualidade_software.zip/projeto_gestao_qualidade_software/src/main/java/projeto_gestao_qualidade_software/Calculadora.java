package projeto_gestao_qualidade_software;

public class Calculadora {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
