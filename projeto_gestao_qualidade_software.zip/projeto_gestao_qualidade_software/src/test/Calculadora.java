package projeto_gestao_qualidade_software;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class CalculadoraTest {

    private Calculadora calculadora;

    @BeforeEach
    void setUp() {
        calculadora = new Calculadora();
    }

    @Test
    void doisSomaDoisEsperaQuatro() {
        assertEquals(4, calculadora.somaInteiros(2, 2));
    }

    @Test
    void tresSomaSeteEsperaDez() {
        assertEquals(10, calculadora.somaInteiros(3, 7));
    }

    @Test
    void doisSubtraiDoisEsperaZero() {
        assertEquals(0, calculadora.subtraiInteiros(2, 2));
    }

    @Test
    void tresMultiplicaSeteEsperaVinteEUm() {
        assertEquals(21, calculadora.multiplicaInteiros(3, 7));
    }

    @Test
    void oitoDividiDoisEsperaQuatro() {
        assertEquals(4, calculadora.dividiInteiros(8, 2));
    }

    @Test
    void divisaoPorZeroDeveLancarExcecao() {
        assertThrows(IllegalArgumentException.class, () -> calculadora.dividiInteiros(10, 0));
    }
}
